import { Link } from '@tanstack/react-router';
import { useState } from 'react';
import { queryOptions, useQuery } from '@tanstack/react-query';
import { ArrowRight, Check, MessageCircle, Sparkles, Zap, Palette, Package, CreditCard, Users, ChartNoAxesCombined, Plus, Minus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { features, steps } from '@/lib/storva';
import { PublicShell } from './public-shell';
import { HowItWorks } from './story-flow';
import { supabase } from '@/integrations/supabase/client';
import { FEATURE_LABELS, formatINR, formatLimit, formatStorage, planFeatures } from '@/lib/plan-rules';

/** Plans come from the same `plans` table that drives limits and billing, so prices and limits shown here are always the real ones. */
const publicPlansQuery = queryOptions({
  queryKey: ['public-plans'],
  queryFn: async () => {
    const { data, error } = await supabase.from('plans').select('id,name,price_monthly,price_yearly,product_limit,order_limit,storage_mb,ai_limit,trial_days,features,sort').order('sort');
    if (error) throw error;
    return data;
  },
});
export function PricingPlans({ yearly, setYearly }: { yearly: boolean; setYearly: (v: boolean) => void }) {
  const { data, isError, isPending } = useQuery(publicPlansQuery);
  const plans = data?.slice(0, 3);
  return <>
    <div className="billing-switch" role="group" aria-label="Billing interval"><Button variant={yearly ? 'ghost' : 'default'} aria-pressed={!yearly} onClick={() => setYearly(false)}>Monthly</Button><Button variant={yearly ? 'default' : 'ghost'} aria-pressed={yearly} onClick={() => setYearly(true)}>Yearly</Button></div>
    {isPending && <p className="pricing-note">Loading plans…</p>}
    {isError && <p className="pricing-note" role="alert">We couldn’t load the plans just now. Please refresh the page.</p>}
    {plans && <div className="pp-grid">{plans.map(p => {
      const free = p.price_monthly === 0;
      const price = yearly ? p.price_yearly : p.price_monthly;
      return <article className={free ? 'pp-card pp-free' : 'pp-card'} key={p.id}>
        {free && <span className="pp-flag">Best place to start</span>}
        <h3>{p.name}</h3>
        <div className="pp-price"><strong>{free ? '₹0' : formatINR(price)}</strong>{!free && <span>{yearly ? 'per year' : 'per month'}</span>}</div>
        <div className="pp-limit"><Package /><span>{free ? <>Start your online store free with up to <b>{formatLimit(p.product_limit)} products</b></> : <>Up to <b>{formatLimit(p.product_limit)} products</b></>}</span></div>
        <Button asChild size="lg" variant={free ? 'default' : 'outline'} className="pp-cta">{free ? <Link to="/login">Start for Free <ArrowRight /></Link> : <Link to="/login" search={{ redirect: '/billing' }}>Choose Plan <ArrowRight /></Link>}</Button>
        <ul>
          <li><Check />{formatLimit(p.order_limit)} orders / month</li>
          <li><Check />{formatStorage(p.storage_mb)} storage</li>
          <li><Check />{p.ai_limit.toLocaleString('en-IN')} AI requests / month</li>
          {planFeatures(p).map(f => <li key={f}><Check />{FEATURE_LABELS[f]}</li>)}
        </ul>
      </article>;
    })}</div>}
    <p className="pricing-note">Prices in Indian rupees. Plans, prices and limits are shown exactly as set in your STORVA account settings.</p>
  </>;
}

const icons = [MessageCircle, Sparkles, Zap, Palette, Package, CreditCard, Users, ChartNoAxesCombined];
export function FeatureGrid({ compact = false }: { compact?: boolean }) {
  return <div className="feature-grid">{features.slice(0, compact ? 4 : 8).map(([title, text], i) => { const Icon = icons[i] ?? Package; return <article className="feature-item" key={title}><span className={`feature-icon tone-${i % 4}`}><Icon /></span><h3>{title}</h3><p>{text}</p><span className="feature-number">0{i + 1}</span></article>; })}</div>;
}
export const faqs = [['Do I need coding or design skills?', 'No. Pick a theme and change colors, fonts and content in the visual store designer.'], ['What payment options can I offer?', 'The supplied store supports online payments through Razorpay. Gateway activation and transaction charges are set by Razorpay.'], ['Can I use my own domain?', 'Custom domains are not available yet. Every store gets its own STORVA link that you can share with customers.'], ['Can I manage my store on my phone?', 'Yes. The store and management pages are designed for mobile, tablet and desktop.'], ['Which languages does the WhatsApp assistant support?', 'English, Malayalam, Tamil, Hindi, Kannada, Telugu, Arabic, Bengali and Urdu. Availability may vary by message type and official WhatsApp template availability.'], ['Who is STORVA for?', 'Creators, beginners and small brands who want to sell online without the complexity of traditional platforms.']];
export function FaqList() {
  const [expanded, setExpanded] = useState<number | null>(0);
  return <div className="faq-list">{faqs.map(([q, a], i) => <article key={q}><Button variant="ghost" className="faq-question" aria-expanded={expanded === i} onClick={() => setExpanded(expanded === i ? null : i)}>{q}{expanded === i ? <Minus /> : <Plus />}</Button>{expanded === i && <p>{a}</p>}</article>)}</div>;
}
export function StartBand() {
  return <section className="start-band"><div className="site-width"><span className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</span><h2>Ready to open your store?</h2><p>Start on the free plan. Upgrade only when you grow.</p><Button asChild variant="secondary" size="lg"><Link to="/login">Create my store <ArrowRight /></Link></Button></div></section>;
}
export function PublicContent({ page }: { page: 'about' | 'services' | 'how-it-works' | 'pricing' | 'faq' }) {
  const [yearly, setYearly] = useState(false);
  const [expanded, setExpanded] = useState<number | null>(0);
  const titles = { about: ['ABOUT STORVA', 'Small businesses deserve a big stage.', 'A simpler way to get your products online. Built for beginners, creators and small businesses.'], services: ['EVERYTHING, TOGETHER', 'Less busywork. More business.', 'From your first product to your next order, keep everything in one place.'], 'how-it-works': ['HOW IT WORKS', 'Your store in four steps.', 'A little setup. A lot of possibility.'], pricing: ['PRICING', 'Simple Plans. Powerful Possibilities.', 'Start for free and upgrade as your business grows.'], faq: ['A LITTLE CLARITY', 'Questions, answered.', 'Everything you want to know before you start.'] };
  const [eyebrow, title, subtitle] = titles[page];
  const questions = [['Do I need coding or design skills?', 'No. Pick a theme and change colors, fonts and content in the visual store designer.'], ['What payment options can I offer?', 'The supplied store supports online payments through Razorpay. Gateway activation and transaction charges are set by Razorpay.'], ['Can I use my own domain?', 'Custom domains are not available yet. Every store gets its own STORVA link that you can share with customers.'], ['Can I manage my store on my phone?', 'Yes. The store and management pages are designed for mobile, tablet and desktop.'], ['Which languages does the WhatsApp assistant support?', 'English, Malayalam, Tamil, Hindi, Kannada, Telugu, Arabic, Bengali and Urdu. Availability may vary by message type and official WhatsApp template availability.'], ['Who is STORVA for?', 'Creators, beginners and small brands who want to sell online without the complexity of traditional platforms.']];
  return <PublicShell><main><section className="page-intro site-width"><span className="eyebrow">{eyebrow}</span><h1>{title}</h1><p>{subtitle}</p></section><section className="site-width content-section">
    {page === 'services' && <FeatureGrid />}
    {page === 'about' && <><img className="about-image" src={steps[3]?.image} alt="Launching an online store with STORVA" /><div className="about-columns">{[['What it is', 'A simple store builder that helps you launch a clean, modern online store without code.'], ['Why it exists', 'Less complexity. More clarity. A few thoughtful templates and a straightforward path to launch.'], ['What you get', 'Your storefront, product catalog, orders and WhatsApp tools, all in one place.']].map(([h, p]) => <article key={h}><h2>{h}</h2><p>{p}</p></article>)}</div></>}
    {page === 'how-it-works' && <HowItWorks headless />}
    {page === 'pricing' && <PricingPlans yearly={yearly} setYearly={setYearly} />}
    {page === 'faq' && <div className="faq-list">{questions.map(([q, a], i) => <article key={q}><Button variant="ghost" className="faq-question" aria-expanded={expanded === i} onClick={() => setExpanded(expanded === i ? null : i)}>{q}{expanded === i ? <Minus /> : <Plus />}</Button>{expanded === i && <p>{a}</p>}</article>)}</div>}
  </section><StartBand /></main></PublicShell>;
}
