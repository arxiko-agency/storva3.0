import { createFileRoute, Link } from '@tanstack/react-router';
import { useState } from 'react';
import { ArrowRight, ArrowDown, Check, Shirt, Cake, Hand, Gift, House, Store } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { PublicShell } from '@/components/public-shell';
import { HeroVisual } from '@/components/hero-visual';
import { FeaturesShowcase } from '@/components/features-showcase';
import { HowItWorks, StoryScroll } from '@/components/story-flow';
import { FaqList, PricingPlans } from '@/components/public-content';
import { pageHead } from '@/lib/storva';

export const Route = createFileRoute('/')({
  head: () => pageHead('Your Business Deserves a Better Online Store', 'Create your online store, manage your products and grow your business with STORVA.'),
  component: Home,
});

const audiences = [
  { icon: Shirt, title: 'Boutiques', text: 'Show every collection beautifully.' },
  { icon: Cake, title: 'Bakeries', text: 'Take orders for fresh, daily bakes.' },
  { icon: Hand, title: 'Handmade Sellers', text: 'Give your craft a home of its own.' },
  { icon: Gift, title: 'Gift Shops', text: 'Make gifting simple for every occasion.' },
  { icon: House, title: 'Home Businesses', text: 'Turn your kitchen table into a real store.' },
];

const svDelay = (d: number) => ({ ['--d' as string]: d });
function Word({ d, children }: { d: number; children: string }) {
  return <span className="sv-w" style={svDelay(d)}>{children}</span>;
}

function Home() {
  const [yearly, setYearly] = useState(false);
  return <PublicShell><main>
    <section className="sv-hero" aria-labelledby="hero-title">
      <div className="sv-hero-bg" aria-hidden="true" />
      <div className="site-width sv-hero-grid">
        <div className="sv-copy">
          <span className="sv-label sv-in" style={svDelay(0)}><span className="sv-pulse" aria-hidden="true" />ONLINE STORES FOR SMALL BUSINESSES</span>
          <h1 id="hero-title" className="sv-title">
            <Word d={2}>Your</Word>{' '}<Word d={3}>Business</Word>{' '}<Word d={4}>Deserves</Word>{' '}<Word d={5}>a</Word>{' '}
            <span className="sv-hl"><Word d={6}>Better</Word>{' '}<Word d={7}>Online</Word>{' '}<Word d={8}>Store</Word></span><Word d={9}>.</Word>
          </h1>
          <p className="sv-desc sv-in" style={svDelay(11)}>Create your online store, manage your products and grow your business with <strong>STORVA</strong>.</p>
          <div className="sv-actions sv-in" style={svDelay(12)}>
            <Button asChild size="lg" className="sv-btn sv-btn-primary"><Link to="/login">Start for Free <ArrowRight /></Link></Button>
            <Button asChild variant="outline" size="lg" className="sv-btn sv-btn-secondary"><Link to="/" hash="features">Explore Features <ArrowDown /></Link></Button>
          </div>
          <ul className="sv-trust sv-in" style={svDelay(13)}>
            {['No coding needed', 'Easy store management', 'Mobile friendly'].map(t => <li key={t}><span><Check strokeWidth={3} /></span>{t}</li>)}
          </ul>
        </div>
        <HeroVisual />
      </div>
    </section>

    <section className="site-width lp-intro">
      <span className="lp-intro-icon"><Store /></span>
      <span className="eyebrow">WHAT IS STORVA</span>
      <h2>One simple home for your online business.</h2>
      <p>STORVA is an online store builder made for small businesses. Launch a clean, modern storefront, manage your products and orders, and take your business online with confidence, all from your phone or computer.</p>
    </section>

    <StoryScroll />

    <FeaturesShowcase />

    <section className="lp-audience"><div className="site-width">
      <div className="lp-center"><span className="eyebrow">WHO CAN USE STORVA</span><h2>Made for businesses like yours.</h2></div>
      <div className="lp-audience-grid">{audiences.map(({ icon: Icon, title, text }) => <article className="lp-card lp-aud-card" key={title}><span className="feature-icon tone-0 lp-icon"><Icon /></span><h3>{title}</h3><p>{text}</p></article>)}</div>
    </div></section>

    <HowItWorks />

    <section id="pricing" className="site-width lp-section lp-anchor">
      <div className="lp-center"><span className="eyebrow">PRICING</span><h2>Simple Plans. Powerful Possibilities.</h2><p className="lp-sub">Start for free and upgrade as your business grows.</p></div>
      <PricingPlans yearly={yearly} setYearly={setYearly} />
    </section>

    <section id="faq" className="site-width lp-section lp-anchor">
      <div className="lp-center"><span className="eyebrow">FAQ</span><h2>Questions, answered.</h2></div>
      <FaqList />
    </section>

    <section className="start-band"><div className="site-width"><span className="eyebrow">YOUR NEXT CHAPTER STARTS HERE</span><h2>Ready to open your store?</h2><p>Start on the free plan. Upgrade only when you grow.</p><Button asChild variant="secondary" size="lg"><Link to="/login">Start for Free <ArrowRight /></Link></Button></div></section>
  </main></PublicShell>;
}
